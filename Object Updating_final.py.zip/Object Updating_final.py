# Author: Qingzi Zheng
# Last modified date: April 21, 2020 
# Purpose: to investigate object-based updating and masking. 
# The stimuli are circles and dots. In a trial, participants see circles and dots moving for several frames. 
# At the last frame, gaps will be shown on the circles, and participants' task is to report the target gap that is on a circle with darker contrast. 
# The gap can be on the left, right, up, or down of the circle. 
# The general phenonmenon is that if the dots remain on the screen after the circles had disappeared (i.e., a delayed offset between the dots and the circles),
# as opposed to if they disappeared at the same time (i.e., simultaneous offset), the dots act as a "mask". 
# The consequence of masking is higher error rate for reporting the gap's side with a delayed offset than that with a simultaneous offset. 
# A speculation of why masking occurs in delayed offset is because as the visual system continues to sample information in the scene, 
# the dots alone are perceived as new states of the previous objects, thus overwriting the representation of the circles with gaps in the previous frame.  
# Interestingly, during the frames in which the circles and dots move, if they move separately so that a perception of them being different objects can be established, 
# then the masking effect will be reduced as compared to if they move together (Moore & Lleras, 2005). This was understood as because different object perceptions 
# were established, the dots with a delayed offset update on their own representations and do not affect the separate representations of the circles, hence reducing masking. 

# The first step of this project aims to replicate this finding with a single dot in each circle. The original experiment has four dots located on the four corners of an imaginary square.
# Although the dots were sparse, one can argue that the imaginary square formed by the dots exceed the boundary of the circle, making masking a phenomenon due to not only perception but also stimulus properties.
# This project will use a single dot, which is the most sparse form of a mask. 
# If the same pattern of results can be obtained here, then it will provide a stronger evidence of masking due to perception. 

# Reference: 
# Moore & Lleras (2005): On the Role of Object Representations in Substitution Masking; 


# import packagaes for this experiment 
from psychopy import visual, event, gui, core, sound, misc
from psychopy.hardware import keyboard
import numpy
import random 

window = None          # window for stimuli to be presented on 
fixation = None        # fixation cross (look like: +) to be presented in the middle of the screen 
blank = None           # blank frame that has no stimulus 
log_file = None        # log file for data to be written in 
kb = None              # key board to record key presses 
numBlock = 10          # number of blocks in the experiment 
block = 0              # block counter to count how many blocks are run 
trial = 0              # trial counter to count how many trials are run 
frame = 11             # number of frames in a trial 
numCircle = 8          # number of circles 
numDot = 8             # number of dots 
circleRadius = 8       # the radius between the center of the screen and the center of each circle 

# a list to control the movement of the circles. 0: no movement, 1: move forward, -1: move backward 
# visual effect: in frame 1, circles are shown. from frame 2 to 5: the circles move forward. from frame 6 to 9: the circles move backward. 
# in frame 10: circles return to the position of where they were shown in frame 1. in frame 11: at that same position, each circle has a gap. 
angle_direction_list = [0, 1, 1, 1, 1, -1, -1, -1, -1, 0, 0]

# a list of arrays for gap directions. index 0:left, 1:right, 2:top, 3:bottom 
gap_direction_list = [[-1,0],[1,0],[0,1],[0,-1]]

# create a 2D array of angles based on the number of frames and circles in the experiment 
circle_angle_list = numpy.ones([frame,numCircle], dtype= int)

# create a box for participants to input their information 
info = {'Age': '18','Gender': 'F', 'Handedness': 'R', 'SubjectID': '99'}
infoDlg = gui.DlgFromDict(dictionary=info, title='Information')
if not infoDlg.OK:  
    core.quit()


# Initialize(): to initialize basic visuals that will be used later, including a window, a fixation cross and a blank frame that is black 
# This function does not have input or output. 

def Initialize():
    global window
    global fixation
    global blank 
    global kb
    global log_file
    
    # initialize a window - the parameters of the window can be changed to suit different monitors 
    window = visual.Window(fullscr = True, monitor = "testMonitor", units = "deg", screen=1, colorSpace = 'hsv', color = (0,0,0))
    
    # hide mouse cursor 
    window.mouseVisible = False
    
    # initialize a fixation cross 
    fixation = visual.ShapeStim(window, vertices = ((0,-0.25), (0,0.25), (0,0), (-0.25,0), (0.25,0)), lineWidth = 2, closeShape = False, lineColorSpace = 'hsv', lineColor = (0,0,0.8))
    
    # initialize a blank (a black screen) for inter-trial intervals 
    blank = visual.Rect(window, width = 150, height = 100, lineColor = (0,0,0), lineColorSpace = 'hsv', fillColor = (0,0,0), fillColorSpace = 'hsv')
    
    # initialize keyboard
    kb = keyboard.Keyboard()
    
    # OU: Object Updating - this is the project name 
    # create a csv file with headers in a row 
    fileName = str(info['SubjectID']) + '-OU'
    log_file = open(fileName + '.csv', 'w') # 'w'- overwrite, 'a' - append
    log_file.write("age" + "," + "gender" + "," + "handedness" + "," + "subject" + "," + "block" + "," + "trial" + "," + 
        "offset" + "," + "sep" + "," + "targ_loc" + "," + "resp" + "," + "rt" + "," + "error" + "\n")


# ShowInstructions(): to show instructions at the beginning of the experiment 
# This function does not have input or output.

def ShowInstructions():
    global window
    
    # height parameter controls font size
    instruction = visual.TextStim(window, height = 0.7, wrapWidth = 10, colorSpace = 'hsv', color = (0,0,0.8), pos = (0, 0))
    
    instruction.text = 'On each trial, you will see an array of circles and dots. Then, they will move around for a while and stop. In the end, one circle will become darker and have a gap. \
        \n Your task is to find this circle and report the orientation of its gap. It can be on the top, bottom, left, or right of the circle. You can report the orientation by pressing the arrow keys.\
        \n \n \n When you are ready, press the space bar to start.'
    
    # the program will not proceed until a 'space' key is pressed 
    while not event.getKeys(keyList = 'space'):
        instruction.draw()
        window.flip()


# ShowBlockText(): to show how many blocks left to complete at the beginning of each block 
# This function does not have input or output.

def ShowBlockText():
    global window
    global block
    
    blockText = visual.TextStim(window, height = 0.7, wrapWidth = 10, colorSpace = 'hsv', color = (0,0,0.8), pos = (0, 0))
    
    blockText.text = 'You have ' + str(numBlock - block + 1) + ' blocks left. When you are ready, press space bar to continue.'
    
    # the program will not proceed until a 'space' key is pressed  
    while not event.getKeys(keyList = 'space'):
        blockText.draw()
        window.flip()


# ShowEnding(): to show that the experiment is completed 
# This function does not have input argument or output argument

def ShowEnding():
    global window
    global block
    
    endText = visual.TextStim(window, height = 0.7, wrapWidth = 10, colorSpace = 'hsv', color = (0,0,0.8), pos = (0, 0))
    
    endText.text = 'Congratulations! You have completed the experiment. Please press space bar to exit.'
    
    # the program will not proceed until a 'space' key is pressed  
    while not event.getKeys(keyList = 'space'):
        endText.draw()
        window.flip()


# drawStim(): to draw the stimuli in the experiment, including circles and dots that move. At the end, gaps are shown and the task is to report a gap that is on a circle with darker contrast. 
# This function has 3 inputs and 1 output. 
# input 1: offset: either 0 (simultaneous offset, the circles and dots disappear together) or 1 (delayed offset: the circles disappear, and the dots remain for additional time) 
# input 2: separation: either 0 (not separated: the circles and dots move together) or 1 (separated: the circles and dots move separately)
# input 3: target: the location of the target circle, can be any integer from 1 to 8 (the target circle that has darker contrast can be at location 1, location 2,..., or location 8) 
# output: returns 1 variable: targ_gap_direction: the direction of the gap on the circle can be 0 (left), 1 (right), 2 (top), 3 (bottowm)

def drawStim(offset, separation, target):
    global window 
    global fixation
    
    # to handle invalid inputs. Any invalid input for one of the three input arguments will terminate the program. 
    if (offset != 0 and offset != 1) or (separation != 0 and separation != 1) or (target < 1 or target > numCircle):
        print ("invalid input.")
        window.close()
        core.quit()
    
    # this nested for-loop is to create a list of circle angles, which will be the angles that circles move 
    # for each frame, an angle is generated to provide an apparent motion such that circles move 
    for f in range (frame):
        # for each circle, an angle is also generated (because each moves independently) 
        for n in range(numCircle):
            angle = random.randint(1,10)
            circle_angle_list[f][n] = angle
    
    
    # this nested for-loop is to draw the stimuli, including circles and dots as well as at the last frame, gaps 
    # for each frame, draw the fixation and determine the direction of the movement  
    for i in range (frame):
        fixation.draw()
        angle_direction = angle_direction_list[i]
        
        # for each circle, determine the position of the circles and draw them  
        for c in range (numCircle):
            circle_angle = numpy.deg2rad(((c+1)/numCircle*360) + circle_angle_list[i][c] * angle_direction)
            circle_x_pos = numpy.cos(circle_angle) * circleRadius
            circle_y_pos = numpy.sin(circle_angle) * circleRadius
            circle = visual.Circle(window, radius = 1, edges = 100, lineWidth = 5, lineColorSpace = 'hsv', lineColor = (0,0,0.8), fillColor = None, 
                pos = (circle_x_pos, circle_y_pos))
            circle.draw()
            
            # if circle and dots move together, then the dots will be at the same position as the circles 
            if separation == 0:
                dot_x_pos = circle_x_pos
                dot_y_pos = circle_y_pos
            
            # else if circle and dots move separately, then the dots will be at different positions as the circles 
            # with the exception that they will be at the same position at the first frame and at the last two frames 
            # to controll them being at the original positions across the two conditions in separation. 
            elif separation == 1: 
                # the first frame and the second to the last frame and the last frame, the dot angles are at the original position 
                if i == 0 or i == frame-2 or i == frame-1:
                    dot_x_pos = circle_x_pos
                    dot_y_pos = circle_y_pos
                
                # other frames, the dots move independently from the circles 
                else:
                    dot_x_pos = circle_x_pos + (random.randint(1,10))/10
                    dot_y_pos = circle_y_pos + (random.randint(1,10))/10
                
            # create dots and draw them
            dot = visual.Circle(window, radius = 0.2, edges = 100, lineColorSpace = 'hsv', lineColor = (0,0,0.8), fillColorSpace = 'hsv', fillColor = (0,0,0.8), 
                size = 0.5, pos = (dot_x_pos, dot_y_pos))
            dot.draw()
            
            # at the last frame, create gaps
            if i == (frame-1):
                gap_direction = random.randint(0,3)
                gap_x = gap_direction_list[gap_direction][0]
                gap_y = gap_direction_list[gap_direction][1]
                gap = visual.Rect(window, width = 1, height = 1, lineWidth = 1, lineColor = (0,0,0), lineColorSpace = 'hsv', 
                    fillColor = (0,0,0), fillColorSpace = 'hsv', pos = (circle_x_pos + gap_x, circle_y_pos + gap_y))
                gap.draw()
        
        # at the last frame, the target circle will have a darker contrast, 
        # and the task is to determine this target circle's gap position: left, right, up, or down 
        if i == (frame-1):
            targ_circle_angle = numpy.deg2rad((target/numCircle)*360)
            targ_circle_x_pos = numpy.cos(targ_circle_angle) * circleRadius
            targ_circle_y_pos = numpy.sin(targ_circle_angle) * circleRadius
            targ_circle = visual.Circle(window, radius = 1, edges = 100, lineWidth = 5, lineColorSpace = 'hsv', lineColor = (0,0,0.3), fillColor = None, 
                pos = (targ_circle_x_pos, targ_circle_y_pos))
            targ_circle.draw()
            
            targ_gap_direction = random.randint(0,3)
            targ_gap_x = gap_direction_list[targ_gap_direction][0]
            targ_gap_y = gap_direction_list[targ_gap_direction][1]
            targ_gap = visual.Rect(window, width = 1, height = 1, lineWidth = 1, lineColor = (0,0,0), lineColorSpace = 'hsv', 
                fillColor = (0,0,0), fillColorSpace = 'hsv', pos = (targ_circle_x_pos + targ_gap_x, targ_circle_y_pos + targ_gap_y))
            targ_gap.draw()
        
        window.flip()
        core.wait(0.15)
        
        # offset == 1: a delayed offset between circles and dots
        # this means after the circles disappear, the dots will be shown alone for an additional amount of time 
        if i == (frame-1) and offset == 1: 
            fixation.draw()
            # for each dot, determine its position and draw it 
            for d in range(numDot): 
                dot_angle = numpy.deg2rad((d+1)/numDot*360) 
                dot_x_pos = numpy.cos(dot_angle) * circleRadius
                dot_y_pos = numpy.sin(dot_angle) * circleRadius
                dot = visual.Circle(window, radius = 0.2, edges = 100, lineColorSpace = 'hsv', lineColor = (0,0,0.8), fillColorSpace = 'hsv', fillColor = (0,0,0.8), 
                    size = 0.5, pos = (dot_x_pos, dot_y_pos))
                dot.draw()
            
            window.flip()
            core.wait(0.2)
    
    # output: the direction of the target gap: can be 0 - left, 1 - right, 2 - top, 3 - bottom 
    return  targ_gap_direction



# RunTrial(): to run a trial 
# This function has 3 inputs and no output. 
# The 3 input variables have the same meaning as that in the drawStim() function becuase the variables are used to call the drawStim() function in each trial 
# Below are short definitions of each input, for detailed explanation, refer to definitions of inputs in drawStim(). 
# offset: either 0 (simultaneous offset) or 1 (delayed offset) 
# separation: either 0 (not separated) or 1 (separated)
# target: the location of the target circle, can be any integer from 1 to 8 becuase there are 8 circles  

def RunTrial(offset, separation, target):
    global window
    global blank 
    global kb
    
    # call the drawStim() function with 3 input arguments
    # use targ_gap_direction to catch the return value (i.e., output) of the drawStim() function 
    targ_gap_direction = drawStim(offset, separation, target)
    
    kb.clock.reset()
    kb.clearEvents()
    
    # between each trial, a blank with no stimulus will be shown
    blank.draw()
    window.flip()
    
    # record key responses, and only this list of keys will be accepted 
    # the program will not proceed until an acceptable key is pressed 
    ptbKeys = []
    while ptbKeys == []:
        ptbKeys = kb.getKeys(['left', 'right','up','down','escape'])
    
    resp = ''
    rt = 0.0
    
    # when a valid key press is registered 
    if ptbKeys != []:
        # if the key is the 'left' arrow key, then change the resp variable (short for response) to be '0' 
        # note: the '' makes '0' a string, not an integer 
        if ptbKeys[0].name == 'left':
            resp += '0'
        # else if the key is the 'right' arrow key, then change the resp variable to be '1'
        elif ptbKeys[0].name == 'right':
            resp += '1'
        # else if the key is the 'up' arrow key, then change the resp variable to be '2'
        elif ptbKeys[0].name == 'up':
            resp += '2'
        # else if the key is the 'down' arrow key, then change the resp variable to be '3'
        elif ptbKeys[0].name == 'down':
            resp += '3'
        # else if the key is the 'escape' key, then close the window and quit the program. 
        # This is written in case the experiment needs to be terminated early. 
        elif ptbKeys[0].name == 'escape':
            window.close()
            core.quit()
        # to format the response time of the key pressed to have 6 decimals 
        rt= f"{ptbKeys[0].rt:.6f}"
    else:
        # just in case if an invalid key is pressed and the system registered it, the response will be '99', which is a different value from a valid key resp value 
        resp += '99'
    
    
    error = ""
    # to compare the value of the resp (i.e., response) and the targ_gap_direction
    # if the values are the same, then error will be '0'
    if int(resp) == targ_gap_direction:
        error = '0'
    # otherwise, error will be '1'. In this case, a beeping noise and a timeout of 1 second will be presented to the participant as a feedback of an error 
    else:
        error = '1'
        beep = sound.Sound(value = 'A', secs = 0.2, volume = 1.0)
        beep.play()
        core.wait(1)
        
    # to record responses to the log file that will be the data file 
    log_file.write(str(info['Age']) + "," + str(info['Gender']) + "," + str(info['Handedness']) + "," + str(info['SubjectID']) + "," + 
        str(block) + "," + str(trial) + "," + str(offset) + "," + str(separation) + "," + 
        str(target) + "," + str(resp) + "," + str(rt) + "," + str(error) + "\n")



# RunTask(): to run the entire experiment, which controls the number of blocks and the number of trials within a block 
# This function does not have input or output.

def RunTask():
    global trial
    global block 
    global window
    
    # at the beginning of the experiment, call ShowInstructions() to show instructions 
    ShowInstructions()
    
    # for each block, update the block counter and reset the trial counter
    # also, call ShowBlockText() to show how many blocks are left to complete 
    for j in range(numBlock):
        block += 1 
        trial = 0
        ShowBlockText()
        
        # the two lines below generate and randomize trial sequences 
        sequence = GenerateTrialSequence()
        RandomizeTrialSequence(sequence)
        
        # for each trial, update the trial counter and call RunTrial() to run the trial with 3 input arguments 
        for i in range(len(sequence)):
            trial += 1
            RunTrial(sequence[i][0],sequence[i][1],sequence[i][2])


# GenerateTrialSequence(): to balance trial types based on offset, separation and target location and to generate the number of trials that will be used to run through each condition.
# This function does not have input, but has 1 output
# output: trials: a list of arrays that has 3 numbers (offset, sep, targ) so that these numbers can later be used to call RunTrial() and drawStim() function 

def GenerateTrialSequence():
    # initialize an empty array that will be updated with trial sequences later 
    trials = [] 
    
    # 3 factors that need to be balanced in this experiment 
    offset_delay = [0,1]    # 0: simultaneous offset; 1: delayed offset 
    sep_levels = [0,1]   # 0: not separated; 1: separated 
    targ_loc = [1,2,3,4,5,6,7,8]    # target locations (depended on how many circles there are in the display)
    
    # note: this 2 x 2 x 8 design will generate 32 trials to run through each condition 
    
    # in these nested for-loops, to run through each level 
    # the inner most level (here, targ_loc) will be run through first, and the outer most level (here, offset) will be run through last 
    for offset in offset_delay: 
        for sep in sep_levels:
            for targ in targ_loc:
                # the numbers in this array will be used as input arguments to call RunTrial(offset, separation, target) 
                # for example: [0,0,1], [0,0,2], [0,0,3] 
                t = [offset, sep, targ] 
                
                # add t to trials (to create an array of trial sequences) 
                trials.append(t)
                
    # output: an array that indicate the trial sequences
    return trials



# RandomizeTrialSequence(): to randomize the order in presenting each trial 
# This function has 1 input but no output. 
# input: trials: the list of arrays that is in order 

def RandomizeTrialSequence(trials): 
    random.shuffle(trials)


# Terminate(): to end the experiment 
# This function has no input or output. 

def Terminate():
    ShowEnding()
    log_file.close()
    window.close()
    core.quit()


# to call functions for the experiment 
Initialize()
RunTask()
Terminate()

